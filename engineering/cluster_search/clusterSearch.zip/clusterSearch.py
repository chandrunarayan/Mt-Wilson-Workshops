#! /usr/bin/python3
"""
This program is used to search for star clusters.
"""
#####################################################################
#    File Name: clusterSearch.py                                    #
#   Written by: Thomas C. Smith                                     #
#           On: 20230216                                            #
#     Modified: 20230421                                            #
#####################################################################
#   Purpose                                                         #
#   - Using input, the program searches for clusters that match the #
#       parameters entered.                                         #
#####################################################################
#   Notes                                                           #
#   - Each function will have a DOCSTRING included                  #
#   - <Optional> place a version on the shiBang line like:          #
#       #! /usr/var/ python3.8                                      #
#   - 20230421 added deails section to the search results           #
#####################################################################
#   Function List                                                   #
#   - doQuit()              # Quits the program                     #
#   - clearMessage()        # Clears the message variable           #
#   - fillClusterIDs()      # Populates the cluster ID list         #
#   - checkResults()        # Conditionalle enables the 'SELECTALL' #
#                           #   button.                             #
#   - putMultipleResults()  # Populates the results listbox         #
#   - doSeatchID(event)     # Loads the selected data into results  #
#   - doSearchNAME2(event)  # Performs a seach using the selected   #
#                           #   name dropdown.                      #
#   - doSearchRADEC()       # Performs a search giving the search   #
#                           #   rectangle created by the RA, DEC,   #
#                           #   and search radius                   #
#   - doResetSearch()       # Clears the fields and outputs         #
#   - selectAll()           # Selects all teh result lines for use  #
#                           #   in the clipboard copy function      #
#   - doCopy2Clipboard()    # Copies the selected results line(s)   #
#                           #   into the clipboard                  #
#   - getSelected(event)    # Populates the details with the line   #
#                           #   selected in the results listbox     #
#####################################################################

#####################################################################
#   Modules and Libraries                                           #
#####################################################################
# Comment out or delete what isn't needed
## Built-in Modules
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import json

## Third-party Modules
import sqlite3 as Db    # Python3 module for sqlite3 database manipulations

## My Modules

#####################################################################
#   End of Modules and Libraries                                    #
#####################################################################

#####################################################################
#   System Variables (Don't change unless know what you are doing)  #
#####################################################################
clusterList     : list  = []    # List of cluster IDs for Combobox
commonNameList  : list  = []    # List of common names for Combobox
resultList      : list  = []    # List to hold results
forCopy         : list  = []    # Items to copy to the clipboard
header          : list = ["M","NGC_IC","ObjID","Const","RA","DEC","RASex","DECSex","R_Sun","R_gc","VMag","Diam","Type","NStars"]
fieldList       : str   = '"M","NGC_IC","objID","Const","RA","DEC","RASex","DECSex","R_Sun","R_gc","VMag","Diam","Type","NStars"'

#####################################################################
#   End of System Variables                                         #
#####################################################################

#####################################################################
#   User Variables                                                  #
#####################################################################


#####################################################################
#   End of User Variables                                           #
#####################################################################

#####################################################################
#   Object Instantiations                                           #
#####################################################################

#####################################################################
#   End of Object Instantiations                                    #
#####################################################################

#####################################################################
#   Program Code                                                    #
#####################################################################
### Support Functions / Methods
def doQuit() -> None:
    """Quits the program."""
    cluster.destroy()
# End doQuit

def clearMessage() -> None:
    """Clears the message and starts the autorun timer."""
    message.set("")
    cluster.after(15000, clearMessage)
# End clearMessage

def fillClusterIDs() -> None:
    """This function queries the database and loads
    the 'clusterList' with the 'objID'."""
    global clusterList
    conn = Db.Connection(dbPath.get())
    cur = conn.cursor()
    # First get the objIDs and if no empy add to the clusterList
    sql = "SELECT M from clusters2 where M <> ''"
    cur.execute(sql)
    ret = list(cur.fetchall())

    lID = len(ret)
    for i in range(lID):
        clusterList.append(ret[i][0])
    CLUSTERIDS.config(values = clusterList)
    # Now fill the common names list
    commonNameList = []
    sql = "SELECT objID from clusters2 where objID <> ''"
    cur.execute(sql)
    ret = cur.fetchall()
    conn.close()
    lRet = len(ret)
    for i in range(lRet):
        commonNameList.append(ret[i][0])
    COMMON.config(values = commonNameList)
# End fillClusterIDs

def checkResults() -> None:
    """Conditionally enables the 'select all' button."""
    if (gotResults.get() == True):
        SELECTALL.config(state = "normal")
    else:
        SELECTALL.config(state = "disabled")
# End checkResults

def putMultiResults(ret : list) -> None:
    """This function takes the multiple results from
    a search and displays the results, one on each line."""
    global fieldList, resultList
    toDisplay = ""
    resultList = ret
    RESULTS.delete(0, tk.END)
    # ret[x] is a tuple so convert it into a list
    if (useHeaders.get() == True):
        RESULTS.insert(tk.END, fieldList)
        
    counter.set(len(ret))
    recCount.set(len(ret))
##  Database schema
##        M TEXT,           0
##        NGC_IC TEXT,      1
##        ObjID TEXT,       2
##        Const TEXT,       3
##        RA REAL,          4
##        DEC REAL,         5
##        RASex TEXT,       6
##        DECSex TEXT,      7
##        R_Sun REAL,       8  
##        R_gc REAL,        9  
##        VMag REAL,        10
##        Diam REAL,        11
##        Type TEXT,        12
##        NStars INTEGER)   13
    strTup = ""
    for rec in resultList:
        strTup = ""
        # rec is a tuple so use the indexes for loading variables
        for tup in rec:
            strTup = strTup + str(tup) + ","
        
        RESULTS.insert(tk.END, strTup)
# End putMultiResults

def doSearchID(event) -> None:
    """This function performs the search on the 'objID' ('M field')."""
    global resultList
    ret = ""
    conn = Db.Connection(dbPath.get())
    cur = conn.cursor()
    # Turn on headers
    header = "M,NGC_IC,ObjID,Const,RA,DEC,RASex,DECSex,R_Sun,R_gc,VMag,Diam,Type,NStars"
    sql = f"SELECT * FROM {tableName.get()} WHERE M = '{CLUSTERIDS.get()}'"
    cur.execute(sql)
    ret = cur.fetchone()
    conn.close()
    # Format the output
    # RA add ':' where space is
    newRA = str(ret[2]).replace(" ", ":")
    # DEC same thing
    newDEC = str(ret[3]).replace(" ", ":")
    # Fill the COMMON with the value from ret[1]
    COMMON.set(ret[1])
    # Clear the RESULTS
    RESULTS.delete(0, tk.END)
    if (useHeaders.get() == True):
        RESULTS.insert(tk.END, header)

    strRet = ""
    for i in range(len(ret)):
        if (i == len(ret) - 1):
            strRet = strRet + str(ret[i])
        else:
            strRet = strRet + str(ret[i]) + ","
        i += 1

    RESULTS.insert(tk.END, strRet)
    resultList = []
    resultList.append(strRet)
##  Database schema
##        M TEXT,           0
##        NGC_IC TEXT,      1
##        ObjID TEXT,       2
##        Const TEXT,       3
##        RA REAL,          4
##        DEC REAL,         5
##        RASex TEXT,       6
##        DECSex TEXT,      7
##        R_Sun REAL,       8  
##        R_gc REAL,        9  
##        VMag REAL,        10
##        Diam REAL,        11
##        Type TEXT,        12
##        NStars INTEGER)   13

    recCount.set(len(resultList))
    SELECTALL.config(state = "normal")
    gotResults.set(True)
    checkResults()
# End searchID

def doSearchNAME2(event) -> None:
    """This function performs a serach on the 'NAME2'."""
    global resultList
    conn = Db.Connection(dbPath.get())
    cur = conn.cursor()
    header = "M,NGC_IC,ObjID,Const,RA,DEC,RASex,DECSex,S_Sun,S_gc,VMag,Diam,Type,NStars"
    sql = f"SELECT * FROM {tableName.get()} WHERE ObjID = '{COMMON.get()}'"
    cur.execute(sql)
    ret = cur.fetchone()
    conn.close()
    # Format the output
    newRA = str(ret[2]).replace(" ",":")
    # DEC same thing
    newDEC = str(ret[3]).replace(" ", ":")
    # Fill the CLUSTERIDS with the value from ret[0] if there is one
    if (ret[0] != "None"):
        CLUSTERIDS.set("")

    # Clear the RESULTS
    RESULTS.delete(0, tk.END)
    if (useHeaders.get() == True):
        RESULTS.insert(tk.END, header)
    strRet = str(ret[0]) + "," + ret[1] + "," + newRA + "," + newDEC + "," + str(ret[4]) + "," + str(ret[5]) + "," + str(ret[6]) + "," + ret[7]
    strRet = strRet + "," + str(ret[8]) + "," + str(ret[9]) + "," + str(ret[10]) + "," + str(ret[11]) + "," + str(ret[12]) + "," + str(ret[13])
    RESULTS.insert(tk.END, strRet)
    resultList = []
    resultList.append(strRet)
##  Database schema
##        M TEXT,           0
##        NGC_IC TEXT,      1
##        ObjID TEXT,       2
##        Const TEXT,       3
##        RA REAL,          4
##        DEC REAL,         5
##        RASex TEXT,       6
##        DECSex TEXT,      7
##        R_Sun REAL,       8  
##        R_gc REAL,        9  
##        VMag REAL,        10
##        Diam REAL,        11
##        Type TEXT,        12
##        NStars INTEGER)   13

    recCount.set(len(resultList))
    gotResults.set(True)
    checkResults()
# End searchNAME2

def doSearchRADEC() -> None:
    """Takes the 'searchRA' and 'searchDEC' variables
    (in decimal form) along with the 'searchSize'
    variable area in minutes of arc and
    returns the data to the 'RESULTS' associated with that star or
    'None' if no data was found."""
    global fieldList, resultList
    # All parameters are needed to define the search area
    raMissing = ""
    decMissing = ""
    sizeMissing = ""
    if (searchRA.get() == ""):
        raMissing = "RA"
    if (searchDEC.get() ==""):
        decMissing = "DEC"
    if (searchSize.get() == 0):
        sizeMissing = "Size"
    if (raMissing != "" or decMissing != "" or sizeMissing != ""):
        recMsg = f"Missing fields: {raMissing} {decMissing} {sizeMissing}"
        message.set(recMsg)
        return
    conn = Db.Connection(dbPath.get())
    cur = conn.cursor()
    # Create ranges for RA and DEC
    div = round(float(searchSize.get()) / 2,4)
    RALow = round(float(searchRA.get()) - div, 4)
    RAHigh = round(float(searchRA.get()) + div, 4)
    DECLow = round(float(searchDEC.get()) - div, 4)
    DECHigh = round(float(searchDEC.get()) + div, 4)
    sql = f"SELECT * FROM {tableName.get()} WHERE RA between {RALow} and {RAHigh} and DEC between {DECLow} and {DECHigh} ORDER BY RASex, DECSex"
    cur.execute(sql)
    ret = cur.fetchall()
    conn.close()
    RESULTS.delete(0, tk.END)
    if (len(ret) < 1):
        RESULTS.insert(0, "None Found")
        gotResults.set(False)
        recCount.set(0)
        return
    gotResults.set(True)
    recCount.set(len(ret))
    checkResults()
    putMultiResults(ret)
# End searchOnRADEC

def doResetSearch() -> None:
    """This will resert the search variables and
    clears the fields ready for the next search."""
    CLUSTERIDS.set("")
    COMMON.set("")
    RESULTS.delete(0, tk.END)
    searchRA.set("0")
    searchDEC.set("0")
    resultList = []
    forCopy = []
    recCount.set(0)
    searchSize.set(0.0)
    CENTRALRA.focus()
    messier.set("")
    ngc_ic.set("")
    objID.set("")
    const.set("")
    RASex.set("")
    RA.set(0.0)
    DEC.set(0.0)
    R_Sun.set(0.0)
    R_gc.set(0.0)
    DECSex.set("")
    VMag.set(0.0)
    diam.set(0.0)
    Type.set("")
    NStars.set(0)
    message.set("Criteria has been cleared")
# End resetSearch

def selectAll() -> None:
    """Selects all the results."""
    RESULTS.select_set(0, tk.END)
# End selectAll

def doCopy2Clipboard() -> None:
    """This function copies the results that are selected
    into the clipboard."""
    global resultList, forCopy, header
    # First empty the forCopy list and clear the clipboard
    sel = RESULTS.curselection()
    if (len(sel) == 0):
        # Nothing was sselected
        message.set("Nothing selected")
        return
    cluster.clipboard_clear()
    if (resultList == []):
        message.set("Nothing to copy")
        return

    if (useHeaders.get() == 1):
        cluster.clipboard_append(fieldList + "\n")
    for item in sel:
        cluster.clipboard_append(RESULTS.get(item) + "\n")

    message.set("Copied to the clipboard")
# End copy2Clipboard

def getSelected(event) -> None:
    """Populates the details when the result line
    selected from the results list."""
    # Total number of items in the listbox
    # Returns a tuple of index values of the lines selected
    sel = RESULTS.curselection()
    res = ""
    if (sel == ()):
        return
    for item in sel[::-1]:
        res = str(RESULTS.get(item))
    # Populate the detail fields
##  Database schema
##        M TEXT,           0
##        NGC_IC TEXT,      1
##        ObjID TEXT,       2
##        Const TEXT,       3
##        RA REAL,          4
##        DEC REAL,         5
##        RASex TEXT,       6
##        DECSex TEXT,      7
##        R_Sun REAL,       8  
##        R_gc REAL,        9  
##        VMag REAL,        10
##        Diam REAL,        11
##        Type TEXT,        12
##        NStars INTEGER)   13
    arrRes = res.split(",")  
    messier.set(arrRes[0])
    ngc_ic.set(arrRes[1])
    objID.set(arrRes[2])
    const.set(arrRes[3])
    RA.set(arrRes[4])
    DEC.set(arrRes[5])
    RASex.set(arrRes[6])
    DECSex.set(arrRes[7])
    R_Sun.set(arrRes[8])
    R_gc.set(arrRes[9])
    VMag.set(arrRes[10])
    diam.set(arrRes[11])
    Type.set(arrRes[12])
    NStars.set(arrRes[13])
# End getSelected

### End of Support Functions / Methods

### GUI
cluster = tk.Tk()
cluster.title("Open Cluster Search")
cluster.config(background = "tan")

# Frames
inputframe = tk.LabelFrame(cluster, text = "Search Parameters", background = "tan")
inputframe.grid(row = 0, column = 0, columnspan = 6, sticky = ('e','w'))

dropframe = tk.LabelFrame(inputframe, text = "Listed Criteria", background = "tan")
dropframe.grid(row = 0, column = 0, columnspan = 4, sticky = ('e','w'))

radecframe = tk.LabelFrame(inputframe, text = "RA - DEC Search", background = "tan")
radecframe.grid(row = 1, column = 0, columnspan = 4, sticky = ('e','w'))

resultframe = tk.LabelFrame(cluster, text = "Search Results", background = "tan")
resultframe.grid(row = 1, column = 0, columnspan = 6, sticky = ('e','w'))

detailframe = tk.LabelFrame(cluster, text = "Target Details", background = "tan")
detailframe.grid(row = 2, column = 0, columnspan = 6, sticky = ('e','w'))

msgframe = tk.LabelFrame(cluster, text = "Messages", background = "tan")
msgframe.grid(row = 3, column = 0, columnspan = 6, sticky = ('e','w'))

cmdframe = tk.LabelFrame(cluster, text = "Commands", background = "tan")
cmdframe.grid(row = 4, column = 0, columnspan = 6, sticky = ('e','w'))
# Menu

# tkinter variables
message         = tk.StringVar()
dbPath          = tk.StringVar()
tableName       = tk.StringVar()
searchSize      = tk.DoubleVar()
searchRA        = tk.StringVar()
searchDEC       = tk.StringVar()
searchID        = tk.StringVar()
searchCommon    = tk.StringVar()
useHeaders      = tk.BooleanVar()
gotResults      = tk.BooleanVar()
counter         = tk.IntVar()
recCount        = tk.IntVar()
resultSelected  = tk.StringVar()
# DB Fields
messier         = tk.StringVar()
ngc_ic          = tk.StringVar()
objID           = tk.StringVar()
const           = tk.StringVar()
RASex           = tk.StringVar()
RA              = tk.DoubleVar()
DEC             = tk.DoubleVar()
R_Sun           = tk.DoubleVar()
R_gc            = tk.DoubleVar()
DECSex          = tk.StringVar()
VMag            = tk.DoubleVar()
diam            = tk.DoubleVar()
Type            = tk.StringVar()
NStars          = tk.IntVar()

# Initial values
message.set("Welcome to the Cluster Search")
dbPath.set("clusters.sdb")
tableName.set("clusters2")
searchRA.set(0)
searchDEC.set(0)

# Input area
tk.Label(dropframe, text = "Cluster:", background = "tan").grid(row = 0, column = 0, sticky = ('e'))
CLUSTERIDS = ttk.Combobox(dropframe, values = clusterList, state = "readonly", width = 10)
CLUSTERIDS.grid(row = 0, column = 1, columnspan = 2, sticky = ('w'))

tk.Label(dropframe, text = "Common:", background = "tan").grid(row = 0, column = 3, sticky = ('e'))
COMMON = ttk.Combobox(dropframe, values = commonNameList, state = "readonly", width = 15)
COMMON.grid(row = 0, column = 4, columnspan = 2, sticky = ('w'))

tk.Label(radecframe, text = "Central RA:", background = "tan").grid(row = 0, column = 0, sticky = ('e'))
CENTRALRA = tk.Entry(radecframe, textvariable = searchRA, background = "lightblue", width = 6)
CENTRALRA.grid(row = 0, column = 1, sticky = ('w'))
tk.Label(radecframe, text = "hh.hhhh", foreground = "green", background = "tan").grid(row = 0, column = 2, sticky = ('w'))

tk.Label(radecframe, text = "Central DEC:", background = "tan").grid(row = 0, column = 3, sticky = ('e'))
CENTRALDEC = tk.Entry(radecframe, textvariable = searchDEC, background = "lightblue", width = 6)
CENTRALDEC.grid(row = 0, column = 4, sticky = ('w'))
tk.Label(radecframe, text = "+/dd.dddd", foreground = "green", background = "tan").grid(row = 0, column = 5, sticky = ('w'))

tk.Label(radecframe, text = "Search Size:", background = "tan").grid(row = 1, column = 0, sticky = ('e'))
SEARCHSIZE = tk.Entry(radecframe, textvariable = searchSize, background = "lightblue", width = 6)
SEARCHSIZE.grid(row = 1, column = 1, sticky = ('w'))
tk.Label(radecframe, text = "Search square size in minutes of arc", foreground = "green", background = "tan").grid(row = 1, column = 2, columnspan = 3, sticky = ('w'))
DOSEARCH = tk.Button(radecframe, text = "Search", foreground = "green", activeforeground = "green", width = 6,
                     cursor = "hand2", command = doSearchRADEC)
DOSEARCH.grid(row = 1, column = 5, sticky = ('e'))

# Results area
USEHEADERS = tk.Checkbutton(resultframe, text = "Include Clipboard Header Row", background = "lightblue", activebackground = "lightblue",
                               variable = useHeaders, onvalue = 1, offvalue = 0, state = "normal")
USEHEADERS.grid(row = 0, column = 0, sticky = ('w'))

INST = tk.Label(resultframe, text = "Select rows to copy or ", background = "tan", foreground = "blue").grid(row = 0, column = 1, sticky = ('e'))

SELECTALL = tk.Button(resultframe, text = "Select ALL", foreground = "blue", activeforeground = "blue", width = 6,
                      cursor = "hand2", state = "disabled", command = selectAll)
SELECTALL.grid(row = 0, column = 2, sticky = ('e'))

tk.Label(resultframe, text = "Record Count:", background = "tan").grid(row = 1, column = 0, sticky = ('e'))
RECORDCOUNT = tk.Label(resultframe, textvariable = recCount, background = "lightyellow", width = 3)
RECORDCOUNT.grid(row = 1, column = 1, sticky = ('w'))

RESULTS = tk.Listbox(resultframe, background = "lightyellow", selectmode = "single", width = 75, height = 10)
RESULTS.grid(row = 2, column = 0, columnspan = 4, rowspan = 10, sticky = ('e','w','n','s'))

# Details Area
tk.Label(detailframe, text = "Messier:", background = "tan").grid(row = 0, column = 0, sticky = ('e'))
MESSIER = tk.Label(detailframe, textvariable = messier, background = "lightyellow", width = 5)
MESSIER.grid(row = 0, column = 1, sticky = ('w'))

tk.Label(detailframe, text = "NGC/IC:", background = "tan").grid(row = 0, column = 2, sticky = ('e'))
NGC_IC = tk.Label(detailframe, textvariable = ngc_ic, background = "lightyellow", width = 15)
NGC_IC.grid(row = 0, column = 3, columnspan = 1, sticky = ('w'))

tk.Label(detailframe, text = "Object ID:", background = "tan").grid(row = 0, column = 4, sticky = ('e'))
OBJID = tk.Label(detailframe, textvariable = objID, background = "lightyellow", width = 20)
OBJID.grid(row = 0, column = 5, sticky = ('w'))

tk.Label(detailframe, text = "Constallation:", background = "tan").grid(row = 1, column = 0, sticky = ('e'))
CONST = tk.Label(detailframe, textvariable = const, background = "lightyellow", width = 5)
CONST.grid(row = 1, column = 1, sticky = ('w'))

tk.Label(detailframe, text = "RA Sex:", background = "tan").grid(row = 1, column = 2, sticky = ('e'))
RASEX = tk.Label(detailframe, textvariable = RASex, background = "lightyellow", width = 10)
RASEX.grid(row = 1, column = 3, sticky = ('w'))

tk.Label(detailframe, text = "DEC Sex:", background = "tan").grid(row = 1, column = 4, sticky = ('e'))
DECSEX = tk.Label(detailframe, textvariable = DECSex, background = "lightyellow", width = 10)
DECSEX.grid(row = 1, column = 5, sticky = ('w'))

tk.Label(detailframe, text = "V Mag:", background = "tan").grid(row = 2, column = 0, sticky = ('e'))
VMAG = tk.Label(detailframe, textvariable = VMag, background = "lightyellow", width = 5)
VMAG.grid(row = 2, column = 1, sticky = ('w'))

tk.Label(detailframe, text = "Diameter:", background = "tan").grid(row = 2, column = 2, sticky = ('e'))
DIAMETER = tk.Label(detailframe, textvariable = diam, background = "lightyellow", width = 5)
DIAMETER.grid(row = 2, column = 3, sticky = ('w'))

tk.Label(detailframe, text = "Type:", background = "tan").grid(row = 2, column = 4, sticky = ('e'))
TYPE = tk.Label(detailframe, textvariable = Type, background = "lightyellow", width = 8)
TYPE.grid(row = 2, column = 5, sticky = ('w'))

tk.Label(detailframe, text = "Num Stars:", background = "tan").grid(row = 3, column = 0, sticky = ('e'))
NSTARS = tk.Label(detailframe, textvariable = NStars, background = "lightyellow", width = 5)
NSTARS.grid(row = 3, column = 1, sticky = ('w'))

# Message area
tk.Label(msgframe, text = "Message:", background = "black", foreground = "yellow").grid(row = 0, column = 0, sticky = ('e'))
MESSAGE = tk.Label(msgframe, textvariable = message, background = "lightyellow", width = 40)
MESSAGE.grid(row = 0, column = 1, columnspan = 3, sticky = ('w'))

# Command area
DOQUIT = tk.Button(cmdframe, text = "Quit", foreground = "red", activeforeground = "red", width = 4,
                   cursor = "hand2", command = doQuit)
DOQUIT.grid(row = 0, column = 0, sticky = ('w'))

COPY2CLIPBOARD = tk.Button(cmdframe, text = "Copy To Clipboard", foreground = "blue", activeforeground = "blue", width = 12,
                           cursor = "hand2", command = doCopy2Clipboard)
COPY2CLIPBOARD.grid(row = 0, column = 2, sticky = ('e'))

RESETSEARCH = tk.Button(cmdframe, text = "Reset Search", foreground = "blue", activeforeground = "blue", width = 10,
                  cursor = "hand2", command = doResetSearch)
RESETSEARCH.grid(row = 0, column = 3, sticky = ('e'))

# # Immediate function calls
fillClusterIDs()
clearMessage()
CENTRALRA.focus()

# Bindings
CLUSTERIDS.bind("<<ComboboxSelected>>",doSearchID)
COMMON.bind("<<ComboboxSelected>>", doSearchNAME2)
RESULTS.bind("<<ListboxSelect>>", getSelected)

# Global layouts
for child in inputframe.winfo_children():child.grid_configure(padx = 2, pady = 2)
for child in dropframe.winfo_children():child.grid_configure(padx = 2, pady = 2)
for child in radecframe.winfo_children():child.grid_configure(padx = 2, pady = 2)
for child in resultframe.winfo_children():child.grid_configure(padx = 2, pady = 2)
for child in detailframe.winfo_children():child.grid_configure(padx = 2, pady = 2)
for child in msgframe.winfo_children():child.grid_configure(padx = 2, pady = 2)
for child in cmdframe.winfo_children():child.grid_configure(padx = 7, pady = 2)


cluster.mainloop()

#####################################################################
#   End of Program Code                                             #
#####################################################################

#####################################################################
#   Testing Code and Script Names, or Function Tests                #
#####################################################################


#####################################################################
#   End of Test Code ans Scripts                                    #
#####################################################################
